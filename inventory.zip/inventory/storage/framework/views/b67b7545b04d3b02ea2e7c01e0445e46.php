<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
      <div class="row">
        <nav class="footer-nav">
          <ul>
            <li><a href="#" target="_blank">Depon Parid</a></li>
          </ul>
        </nav>
        <div class="credits ml-auto">
          
        </div>
      </div>
    </div>
  </footer>
<?php /**PATH D:\laragon\www\sc_laravel\inventory\resources\views/footer.blade.php ENDPATH**/ ?>